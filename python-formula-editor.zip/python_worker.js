/**
 * python_worker.js — SAC Python Formula Editor
 *
 * Runs entirely in a Web Worker. Responsibilities:
 *  - Load Pyodide once and keep it alive for the widget's lifetime.
 *  - Build pandas DataFrames from SAC ResultSet row arrays with hash-based caching.
 *  - Cache compiled Python code objects (compile() → PyProxy) to skip repeated parsing.
 *  - Inject SAC helper functions (store_result, filter_scope, set_scope, display) into
 *    every execution namespace.
 *  - Report COMPILE_RESULT markers (line/col) for Monaco inline error decorations.
 *
 * Message protocol
 * ─────────────────
 * Widget → Worker:  { id, type, payload }
 *   INIT           { pyodideJsUrl, pyodideIndexURL }
 *   EXECUTE        { script, bindings[], variables{} }
 *   TEST_EXECUTE   { script, bindings[], variables{} }   ← never writebacks
 *   COMPILE_CHECK  { script }
 *   SET_FILTER     { bindingId, dim, members[] }
 *   PING           {}
 *
 * Worker → Widget:  { id, type, payload }
 *   WORKER_READY   {}
 *   PYODIDE_READY  { durationMs }
 *   PYODIDE_ERROR  { error }
 *   COMPILE_RESULT { errors[] }
 *   EXEC_RESULT    { results{}, filterQueue[], stdout, durationMs }
 *   EXEC_ERROR     { error, lineNumber, traceback, stdout }
 *   TEST_EXEC_RESULT { results{}, assertions[], stdout, durationMs, passed, failCount }
 *   TEST_EXEC_ERROR  { error, lineNumber, traceback, stdout }
 *   PONG           {}
 */

'use strict';

/* ─── Worker state ─────────────────────────────────────────────────────────── */
const _state = {
  pyodide:       null,
  pyodideReady:  false,
  initPromise:   null,

  /** compiledCache[scriptHash] = PyProxy code object from compile().
   *  Capped at MAX_COMPILED_CACHE entries (LRU order via _compiledOrder array). */
  compiledCache: {},
  _compiledOrder: [],
  MAX_COMPILED_CACHE: 50,

  /** dfCache[slotName] = { hash: string, df: PyProxy }
   *  DataFrame rebuilt only when ResultSet hash changes. */
  dfCache: {},
};

/* ─── Announce readiness immediately ──────────────────────────────────────── */
self.postMessage({ type: 'WORKER_READY', id: null, payload: {} });

/* ─── Message dispatcher ───────────────────────────────────────────────────── */
self.onmessage = async (event) => {
  const { id, type, payload = {} } = event.data;

  try {
    switch (type) {
      case 'INIT':
        await handleInit(id, payload);
        break;
      case 'EXECUTE':
        await handleExecute(id, payload, false);
        break;
      case 'TEST_EXECUTE':
        await handleExecute(id, payload, true);
        break;
      case 'COMPILE_CHECK':
        await handleCompileCheck(id, payload);
        break;
      case 'SET_FILTER':
        handleSetFilter(id, payload);
        break;
      case 'PING':
        self.postMessage({ type: 'PONG', id, payload: {} });
        break;
      default:
        console.warn('[PFE Worker] Unknown message type:', type);
    }
  } catch (err) {
    self.postMessage({
      type: 'EXEC_ERROR',
      id,
      payload: { error: err.message || String(err), traceback: err.stack || '', lineNumber: null, stdout: '' }
    });
  }
};

/* ═══════════════════════════════════════════════════════════════════════════
   SECTION B — Pyodide Initialisation
   ═══════════════════════════════════════════════════════════════════════════ */

async function handleInit(id, { pyodideJsUrl, pyodideIndexURL, pyodideVersion = '0.26.4' }) {
  if (_state.pyodideReady) {
    self.postMessage({ type: 'PYODIDE_READY', id, payload: { durationMs: 0 } });
    return;
  }
  if (_state.initPromise) {
    await _state.initPromise;
    self.postMessage({ type: 'PYODIDE_READY', id, payload: { durationMs: 0 } });
    return;
  }

  _state.initPromise = (async () => {
    const t0 = performance.now();
    try {
      /* Load pyodide.js from local vendor bundle (no external script-src needed).
         Falls back to CDN if pyodideJsUrl is not provided (e.g. during development). */
      const jsUrl = pyodideJsUrl
        || `https://cdn.jsdelivr.net/pyodide/v${pyodideVersion}/full/pyodide.js`;
      importScripts(jsUrl);

      /* indexURL controls where the WASM binary and packages are fetched from.
         Defaults to jsdelivr; override with pyodideBaseURL widget property to
         point at an internal server and eliminate all external CDN dependencies. */
      const indexURL = pyodideIndexURL
        || `https://cdn.jsdelivr.net/pyodide/v${pyodideVersion}/full/`;

      _state.pyodide = await loadPyodide({ indexURL });

      /* Install packages — pandas & numpy bundled with Pyodide, micropip for extras */
      await _state.pyodide.loadPackage(['pandas', 'numpy', 'micropip']);

      /* One-time bootstrap: define SAC helper functions in Pyodide globals */
      await _state.pyodide.runPythonAsync(SAC_HELPERS_BOOTSTRAP);

      _state.pyodideReady = true;
      const durationMs = Math.round(performance.now() - t0);
      self.postMessage({ type: 'PYODIDE_READY', id, payload: { durationMs } });
    } catch (err) {
      self.postMessage({ type: 'PYODIDE_ERROR', id, payload: { error: err.message || String(err) } });
      throw err;
    }
  })();

  await _state.initPromise;
}

/* ═══════════════════════════════════════════════════════════════════════════
   SECTION C — Script Execution
   ═══════════════════════════════════════════════════════════════════════════ */

async function handleExecute(id, { script, bindings = [], variables = {} }, isTest = false) {
  if (!_state.pyodideReady) {
    self.postMessage({
      type: isTest ? 'TEST_EXEC_ERROR' : 'EXEC_ERROR', id,
      payload: { error: 'Pyodide is not ready. Call INIT first.', lineNumber: null, traceback: '', stdout: '' }
    });
    return;
  }

  const t0 = performance.now();
  let stdout = '';

  /* Redirect stdout/stderr */
  _state.pyodide.setStdout({ batched: (s) => { stdout += s; } });
  _state.pyodide.setStderr({ batched: (s) => { stdout += '\n[STDERR] ' + s; } });

  /* Build DataFrames (cached) */
  const dfs = await buildDataFrames(bindings);

  /* Build a fresh execution namespace and reset result collectors */
  const py = _state.pyodide;
  py.globals.set('__sac_results__', py.toPy({}));
  py.globals.set('__sac_filter_queue__', py.toPy([]));
  py.globals.set('__sac_test_assertions__', py.toPy([]));

  /* Build a fresh execution namespace */
  const ns = py.globals.get('dict')();
  injectIntoNamespace(ns, dfs, variables);

  /* Execute. We use runPythonAsync directly on the script source to support
     top-level await (e.g. for micropip.install). */
  try {
    await py.runPythonAsync(script, { globals: ns });
  } catch (pyErr) {
    const lineMatch = pyErr.message && pyErr.message.match(/[Ll]ine (\d+)/);
    self.postMessage({
      type: isTest ? 'TEST_EXEC_ERROR' : 'EXEC_ERROR', id,
      payload: {
        error:       extractPythonMessage(pyErr.message),
        lineNumber:  lineMatch ? parseInt(lineMatch[1], 10) : null,
        traceback:   pyErr.message || '',
        stdout
      }
    });
    ns.destroy();
    return;
  }

  /* Harvest results */
  const rawResults     = py.globals.get('__sac_results__');
  const rawFilterQueue = py.globals.get('__sac_filter_queue__');
  const rawAssertions  = py.globals.get('__sac_test_assertions__');

  let results     = {};
  let filterQueue = [];
  let assertions  = [];
  try {
    results     = rawResults     ? rawResults.toJs({ dict_converter: Object.fromEntries }) : {};
    filterQueue = rawFilterQueue ? rawFilterQueue.toJs() : [];
    assertions  = rawAssertions  ? rawAssertions.toJs()  : [];
  } catch (_) { /* best-effort */ }

  const durationMs = Math.round(performance.now() - t0);
  ns.destroy();

  if (isTest) {
    /* In test mode: no filterQueue sent back (never modifies SAC context) */
    const failCount = assertions.filter(a => !a.passed).length;
    self.postMessage({
      type: 'TEST_EXEC_RESULT', id,
      payload: { results, assertions, stdout, durationMs, passed: failCount === 0, failCount }
    });
  } else {
    self.postMessage({
      type: 'EXEC_RESULT', id,
      payload: { results, filterQueue, stdout, durationMs }
    });
  }
}

/* ═══════════════════════════════════════════════════════════════════════════
   SECTION D — Compile Check (pre-flight for Monaco markers)
   ═══════════════════════════════════════════════════════════════════════════ */

async function handleCompileCheck(id, { script }) {
  if (!_state.pyodideReady) {
    self.postMessage({ type: 'COMPILE_RESULT', id, payload: { errors: [] } });
    return;
  }
  const errors = runCompileCheck(script);
  self.postMessage({ type: 'COMPILE_RESULT', id, payload: { errors } });
}

/** Synchronous compile check — returns Monaco-compatible marker array. */
function runCompileCheck(script) {
  const errors = [];
  try {
    _state.pyodide.runPython(
      `compile(${JSON.stringify(script)}, '<sac_script>', 'exec')`
    );
  } catch (err) {
    const msg = err.message || String(err);
    const lineMatch = msg.match(/[Ll]ine (\d+)/);
    const line = lineMatch ? parseInt(lineMatch[1], 10) : 1;
    errors.push({
      startLineNumber: line,
      startColumn:     1,
      endLineNumber:   line,
      endColumn:       999,
      message:         extractPythonMessage(msg),
      severity:        8  /* monaco.MarkerSeverity.Error */
    });
  }
  return errors;
}

/* ═══════════════════════════════════════════════════════════════════════════
   SECTION E — Set Filter (cache invalidation)
   ═══════════════════════════════════════════════════════════════════════════ */

function handleSetFilter(id, { bindingId }) {
  /* Invalidate the cached DataFrame so it is rebuilt on next EXECUTE
     after SAC applies the filter and returns an updated ResultSet. */
  if (_state.dfCache[bindingId]) {
    try { _state.dfCache[bindingId].df.destroy(); } catch (_) {}
    delete _state.dfCache[bindingId];
  }
  self.postMessage({ type: 'FILTER_APPLIED', id, payload: { bindingId } });
}

/* ═══════════════════════════════════════════════════════════════════════════
   SECTION F — DataFrame Cache
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * For each binding slot, build a pandas DataFrame from the rows array.
 * If the hash matches the cached entry, the existing PyProxy is reused — no
 * Python round-trip needed.
 *
 * @param {Array<{slotName, alias, rows, hash, changed}>} bindings
 * @returns {Object} { [alias]: PyProxy (pandas DataFrame) }
 */
async function buildDataFrames(bindings) {
  const dfs = {};
  for (const b of bindings) {
    const cached = _state.dfCache[b.slotName];
    if (!b.changed && cached && cached.hash === b.hash) {
      dfs[b.alias] = cached.df;
      continue;
    }
    /* Destroy stale proxy before replacing */
    if (cached) {
      try { cached.df.destroy(); } catch (_) {}
    }

    /* Convert rows to a Python list of dicts directly.
       toPy() handles the underlying memory mapping efficiently. */
    const rowsProxy = _state.pyodide.toPy(b.rows || []);
    const df = await _state.pyodide.runPythonAsync(
      `import pandas as _pd; _pd.DataFrame(rows)`,
      { locals: _state.pyodide.toPy({ rows: rowsProxy }) }
    );
    rowsProxy.destroy();

    _state.dfCache[b.slotName] = { hash: b.hash, df };
    dfs[b.alias] = df;
  }
  return dfs;
}

/* ═══════════════════════════════════════════════════════════════════════════
   SECTION G — Compiled Code Cache (LRU, max 50 entries)
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * Returns the compiled PyProxy for `script`, or null if compile() throws.
 * Uses a 50-entry LRU cache keyed by a fast 32-bit hash of the script string.
 */
function getOrCompile(script) {
  const hash = simpleHash(script);
  if (_state.compiledCache[hash]) {
    /* Bump to most-recently-used */
    const idx = _state._compiledOrder.indexOf(hash);
    if (idx > -1) _state._compiledOrder.splice(idx, 1);
    _state._compiledOrder.push(hash);
    return _state.compiledCache[hash];
  }
  /* Compile */
  let codeProxy;
  try {
    codeProxy = _state.pyodide.runPython(
      `compile(${JSON.stringify(script)}, '<sac_script>', 'exec')`
    );
  } catch (_) {
    return null;
  }
  /* Evict oldest if at capacity */
  if (_state._compiledOrder.length >= _state.MAX_COMPILED_CACHE) {
    const oldest = _state._compiledOrder.shift();
    try { _state.compiledCache[oldest].destroy(); } catch (_) {}
    delete _state.compiledCache[oldest];
  }
  _state.compiledCache[hash] = codeProxy;
  _state._compiledOrder.push(hash);
  return codeProxy;
}

/* ═══════════════════════════════════════════════════════════════════════════
   SECTION H — Namespace Injection
   ═══════════════════════════════════════════════════════════════════════════ */

/**
 * Populate a Python dict (ns) with:
 *  - All DataFrames by their user alias.
 *  - All SAC input variables as Python strings/numbers.
 *  - SAC helper functions (store_result, filter_scope, set_scope, display).
 *  - Standard library aliases (pd, np, json, math, re).
 */
function injectIntoNamespace(ns, dfs, variables) {
  const py = _state.pyodide;
  const g  = py.globals;

  /* DataFrames */
  for (const [alias, df] of Object.entries(dfs)) {
    ns.set(alias, df);
  }

  /* SAC variables */
  for (const [name, val] of Object.entries(variables)) {
    try {
      ns.set(name, py.toPy(val));
    } catch (_) {
      ns.set(name, py.toPy(String(val)));
    }
  }

  /* Helpers defined in SAC_HELPERS_BOOTSTRAP */
  for (const fn of ['store_result', 'filter_scope', 'set_scope', 'display', 'debug', 'assert_equal', 'df_info']) {
    const proxy = g.get(fn);
    if (proxy) ns.set(fn, proxy);
  }

  /* Standard library aliases */
  for (const lib of ['pd', 'np', 'json', 'math', 're']) {
    const proxy = g.get(lib);
    if (proxy) ns.set(lib, proxy);
  }
}

/* ═══════════════════════════════════════════════════════════════════════════
   SECTION I — Utility Functions
   ═══════════════════════════════════════════════════════════════════════════ */

/** Fast non-cryptographic 32-bit hash of a string (djb2 variant). */
function simpleHash(str) {
  let hash = 5381;
  for (let i = 0; i < str.length; i++) {
    hash = ((hash << 5) + hash) ^ str.charCodeAt(i);
    hash |= 0; /* force 32-bit signed integer */
  }
  return (hash >>> 0).toString(16); /* unsigned hex string */
}

/** Strip Pyodide's internal traceback boilerplate, keep the user-visible message. */
function extractPythonMessage(msg) {
  if (!msg) return 'Unknown error';
  /* Last non-empty line is usually the most descriptive */
  const lines = msg.split('\n').map(l => l.trim()).filter(Boolean);
  return lines[lines.length - 1] || msg;
}

/* ═══════════════════════════════════════════════════════════════════════════
   SECTION J — SAC Helpers Bootstrap (embedded Python, executed once at init)
   ═══════════════════════════════════════════════════════════════════════════ */

const SAC_HELPERS_BOOTSTRAP = `
import pandas as pd
import numpy as np
import json
import math
import re
from io import StringIO

# ── Internal result and filter collectors ────────────────────────────────────
__sac_results__     = {}
__sac_filter_queue__ = []

# ── store_result ─────────────────────────────────────────────────────────────
def store_result(key, value):
    """
    Queue a calculation result for display (debug mode) or writeback (production mode).

    Parameters
    ----------
    key : str
        In debug mode: any descriptive string.
        In production mode use the compound writeback key format:
            "{bindingSlot}.{measureId}.{dim1=val1,dim2=val2}"
        Example: "dataBinding1.Revenue.Region=EMEA,Year=2024"
    value : any
        Any JSON-serialisable value. pandas DataFrames and Series are
        automatically converted to dicts/records before queuing.
    """
    global __sac_results__
    if isinstance(value, pd.DataFrame):
        value = value.to_dict(orient='records')
    elif isinstance(value, pd.Series):
        value = value.to_dict()
    elif isinstance(value, np.integer):
        value = int(value)
    elif isinstance(value, np.floating):
        value = float(value)
    elif isinstance(value, np.ndarray):
        value = value.tolist()
    __sac_results__[str(key)] = value

# ── filter_scope ─────────────────────────────────────────────────────────────
def filter_scope(df, **kwargs):
    """
    Return a filtered copy of a DataFrame using dimension=value conditions.
    Does NOT modify the SAC query — operates purely in Python memory.

    Parameters
    ----------
    df : pd.DataFrame
        The DataFrame to filter (typically a dataBinding variable).
    **kwargs
        Dimension name = single value or list of values.
        Example: filter_scope(sales, Region='EMEA', FiscalYear=[2023, 2024])

    Returns
    -------
    pd.DataFrame
        Filtered copy of df.

    Raises
    ------
    KeyError
        If a dimension name is not a column in df.
    """
    result = df.copy()
    for dim, val in kwargs.items():
        if dim not in result.columns:
            raise KeyError(
                f"Dimension '{dim}' not found. Available columns: {list(result.columns)}"
            )
        if isinstance(val, (list, tuple, set)):
            result = result[result[dim].isin(list(val))]
        else:
            result = result[result[dim] == val]
    return result

# ── set_scope ─────────────────────────────────────────────────────────────────
def set_scope(binding_id, **kwargs):
    """
    Queue an SAC-side setFilter call for a binding slot.
    The widget applies these filters after the script completes, which causes
    SAC to re-execute the underlying query with the new filter scope.

    Parameters
    ----------
    binding_id : str
        The slot name, e.g. 'dataBinding1'.
    **kwargs
        Dimension name = single value or list of values.
        Example: set_scope('dataBinding1', Region=['EMEA', 'APJ'])
    """
    global __sac_filter_queue__
    for dim, val in kwargs.items():
        members = list(val) if isinstance(val, (list, tuple, set)) else [val]
        __sac_filter_queue__.append({
            'bindingId': str(binding_id),
            'dim':       str(dim),
            'members':   [str(m) for m in members]
        })

# ── display ───────────────────────────────────────────────────────────────────
def display(obj):
    """
    Pretty-print an object to the widget output panel.
    Prints DataFrames as formatted tables, dicts/lists as indented JSON,
    and all other objects via repr().
    """
    if isinstance(obj, pd.DataFrame):
        print(obj.to_string(index=True))
    elif isinstance(obj, (dict, list)):
        print(json.dumps(obj, indent=2, default=str))
    elif isinstance(obj, pd.Series):
        print(obj.to_string())
    else:
        print(repr(obj))

# ── debug() — enhanced display with type and shape info ──────────────────────
def debug(label, obj=None):
    """
    Enhanced diagnostic display with type, shape, and preview.

    Usage
    -----
    debug('my variable', df)   → prints label + DataFrame info + head(5)
    debug(df)                  → label inferred as repr(df)[:40]
    debug('total', 42)         → prints type + value

    Available in both normal and test mode.
    """
    if obj is None:
        obj, label = label, str(type(label).__name__)
    type_name = type(obj).__name__
    if isinstance(obj, pd.DataFrame):
        print(f"[DEBUG] {label}: DataFrame  shape={obj.shape}  columns={list(obj.columns)}")
        null_counts = {c: int(n) for c, n in obj.isnull().sum().items() if n > 0}
        if null_counts:
            print(f"  null counts: {null_counts}")
        print(obj.head(5).to_string())
    elif isinstance(obj, pd.Series):
        print(f"[DEBUG] {label}: Series  len={len(obj)}  dtype={obj.dtype}")
        print(obj.head(5).to_string())
    elif isinstance(obj, (list, tuple)):
        print(f"[DEBUG] {label}: {type_name}  len={len(obj)}")
        print(repr(obj[:5]))
    elif isinstance(obj, dict):
        print(f"[DEBUG] {label}: dict  keys={list(obj.keys())[:10]}")
        print(json.dumps(dict(list(obj.items())[:5]), indent=2, default=str))
    elif isinstance(obj, np.ndarray):
        print(f"[DEBUG] {label}: ndarray  shape={obj.shape}  dtype={obj.dtype}")
        print(repr(obj.flat[:10]))
    else:
        print(f"[DEBUG] {label}: {type_name}  =  {repr(obj)}")

# ── assert_equal() — test assertions ─────────────────────────────────────────
__sac_test_assertions__ = []

def assert_equal(label, actual, expected, tolerance=None):
    """
    Assert actual == expected and record the result for the test output panel.

    Parameters
    ----------
    label     : str   Human-readable test name.
    actual    : any   Computed value.
    expected  : any   Expected value.
    tolerance : float Optional numeric tolerance (uses abs(actual - expected) <= tolerance).

    Returns
    -------
    bool  True if assertion passed.

    Example
    -------
    total = df['Revenue'].sum()
    assert_equal('Total Revenue', total, 1_800_000, tolerance=0.01)
    """
    global __sac_test_assertions__
    try:
        if tolerance is not None:
            passed = abs(float(actual) - float(expected)) <= float(tolerance)
        else:
            passed = actual == expected
    except Exception as e:
        passed = False
    status = "✓ PASS" if passed else "✗ FAIL"
    print(f"{status}: {label}  actual={repr(actual)}  expected={repr(expected)}")
    __sac_test_assertions__.append({
        'label':    str(label),
        'passed':   bool(passed),
        'actual':   repr(actual),
        'expected': repr(expected)
    })
    return bool(passed)

# ── df_info() — DataFrame diagnostics ────────────────────────────────────────
def df_info(df, name='df'):
    """
    Print a concise diagnostic report for a DataFrame.
    Includes: shape, column names, dtypes, null counts, and first 3 rows.
    """
    print(f"[INFO] {name}: shape={df.shape}")
    print(f"  columns : {list(df.columns)}")
    dtype_map = {c: str(t) for c, t in df.dtypes.items()}
    print(f"  dtypes  : {dtype_map}")
    nulls = {c: int(n) for c, n in df.isnull().sum().items() if n > 0}
    if nulls:
        print(f"  nulls   : {nulls}")
    print(f"  preview :")
    print(df.head(3).to_string())
`;

